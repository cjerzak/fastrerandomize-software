# This file is automatically sourced by R CMD check
# It runs all tests in the testthat/ directory

library(testthat)
library(fastrerandomize)

test_check("fastrerandomize")
